# 🎂 Birthday Wish — Premium Animated Site

A single-page, fully animated birthday website. Everything you'll want to
personalize lives in **one place**: the `config` object at the top of
`script.js`.

## Files

```
index.html          the page structure
style.css            all styling, themes, animations
script.js             config object + all interactivity
assets/images/       gallery photos, gift GIF (placeholders included)
assets/music/         background music (add your own mp3)
```

## Quick start

1. Open `script.js` and edit the `config` object at the top:
   - `name`, `age`, `message`, `specialWishes`, `memories`, `closing`
   - `birthdayMonth` / `birthdayDay` — powers the countdown
   - `letter` — the handwritten-style envelope letter
   - `gallery` — array of `{ src, alt }` pointing at your own photos
   - `reasons` — the "10 Reasons You're Amazing" list
   - `surpriseMessage`, `giftBoxMessage`, `quotes`, `yourName`
2. Replace the placeholder images in `assets/images/` with real photos,
   keeping the same file names (or update `config.gallery` to match new
   names).
3. Drop an MP3 into `assets/music/` named `until-i-found-you.mp3` (the player
   is already labeled "Until I Found You — Stephen Sanchez") — or change the
   `<source>` path in `index.html` and the `#musicTitle` text if you'd rather
   use a different song.
4. Replace `assets/images/surprise.gif` with any celebration GIF you like.
5. Open `index.html` in a browser — no build step required.

## Notes

- **Themes**: click the colored dots (top-left) to switch between Pink,
  Purple, Blue, Gold, and Dark. The user's choice is remembered via
  `localStorage`.
- **Countdown**: automatically rolls to next year once the birthday passes,
  and triggers confetti + fireworks + music when it hits zero.
- **Music autoplay**: browsers block audio until a user gesture, so playback
  starts on the "Click to Open Your Surprise" button, exactly as requested.
- **Visitor counter** is a simple per-browser `localStorage` counter (no
  backend). Swap in a real API if you want a shared, global count.
- **Print/Save Letter** opens the browser's print dialog styled to only show
  the letter — use "Save as PDF" in the print dialog for a PDF copy.
- All effects respect `prefers-reduced-motion`.

Made with ❤️ — happy customizing!
